<div class="front-as" style="animation: positBrand 1.6s ease-in-out;">
    RECEBA DIARIAMENTE ANALISES DE TRADER ESPORTIVO DIRETAMENTE PELO SEU CELULAR E <b class="cor-verde">LUCRE</b> DE FORMA <b class="cor-verde">SIMPLES</b> APENAS COPIANDO OS SINAIS.
</div>
<span class="partida-se" style="animation: positBrand 1.4s ease-in-out;">MESMO SEM ENTENDER NADA DO MERCADO ESPORTIVO
</span>
</div>