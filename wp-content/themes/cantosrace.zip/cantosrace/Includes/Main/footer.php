<?php wp_footer(); ?>

<div id="footer">
	<div class="creditos">
		<p>© COPYRIGHT - Todos os direitos reservados 2021 - Cantos Race.</p>
	</div>
</div>



<!-- JS -->
<!-- PRIMARY KEY -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://kit.fontawesome.com/13e0382c7c.js"></script>
