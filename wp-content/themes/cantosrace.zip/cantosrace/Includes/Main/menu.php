<div id="menu" class="menu">
    <div class="circle"></div>
    <div class="menu-mobile">
        <ul>
            <li id="inicioAbrirResponsv"><a><i style="margin-right: 6px;" class="fas fa-home"></i>Inicio</a></li>
            <li><a href="#beneficios"><i style="margin-right: 6px;" class="fas fa-poll"></i> Benefícios</a></li>
            <li><a href="#resultados"><i style="margin-right: 6px;" class="fas fa-dollar-sign"></i> Resultados</a></li>
            <li><a href="#depoimentos"><i style="margin-right: 6px;" class="fas fa-comments"></i> Depoimentos</a></li>
            <li><a href="#"><i style="margin-right: 6px;" class="fab fa-instagram"></i> Instagram</li></a>

        </ul>
    </div>
    <div class="burger">
        <div class="x"></div>
        <div class="y"></div>
        <div class="z"></div>
    </div>


    <div class="position">
        <div class="logo">
        </div>

        <nav>
            <ul id="menutop" class="menuItems">
                <li id="inicioAbrir"><i style="margin-right: 6px;" class="fas fa-home"></i>Inicio</li>
                <a href="#beneficios">
                    <li><i style="margin-right: 6px;" class="fas fa-poll"></i>Benefícios</li>
                </a>
                <a href="#resultados">
                    <li><i style="margin-right: 6px;" class="fas fa-dollar-sign"></i>Resultados</li>
                </a>
                <a href="#depoimentos">
                    <li><i style="margin-right: 6px;" class="fas fa-comments"></i>Depoimentos</li>
                </a>
            </ul>
        </nav>
    </div>
</div>