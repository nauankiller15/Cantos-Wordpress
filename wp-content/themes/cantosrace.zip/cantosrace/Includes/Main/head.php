<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta http-equiv="X-UA-Compatible" ontent="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="Description" CONTENT="Cantos Race">
    <meta name="google-site-verification" content="+nxGUDJ4QpAZ5l9Bsjdi102tLVC21AIh5d1Nl23908vVuFHs34=" />
    <meta name="robots" content="noindex,nofollow">

    <!--  -->
    <!--  -->
    <link rel="icon" href="https://1.bp.blogspot.com/-_EdgLntjH3U/YL5c_Wlk-YI/AAAAAAAAHM8/oQmfyGE1A7Iz5znU7mpYo5CTdev6MAbBQCLcBGAsYHQ/s0/favicon-32x32.png" type="image/png">

    <?php wp_head(); ?>
    <title>CantosRace - (PROMOÇÃO)</title>
</head>