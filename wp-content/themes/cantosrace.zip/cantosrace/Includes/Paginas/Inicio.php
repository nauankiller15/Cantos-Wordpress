<div id="inicio">
    <div id="topo" class="sticky-menu">
        <div class="info-left">
            <div>Siga-nos</div>
            <div class="middle-line"></div>
            <a href="#" target="_blank" class="vertical-link">
                <i class="fab fa-facebook-f"></i></a>
            <a href="https://www.instagram.com/cantosrace/" target="_blank" class="vertical-link">
                <i class="fab fa-instagram"></i></a>
        </div>
    </div>
    <div class="friends-section color-rest">
        <div class="espac-rest">
            <div class="banner-content-half">
                <h1 class="texto-front" style="animation:positBrand 1.8s ease-in-out;">
                    Atenção!
                </h1>
                <div class="front-as" style="animation: positBrand 1.6s ease-in-out;">
                    RECEBA <b class="cor-verde">DIARIAMENTE</b> ANÁLISES DE <b class="cor-verde">TRADER ESPORTIVO</b> DIRETAMENTE PELO SEU CELULAR E <b class="cor-verde">LUCRE</b> DE FORMA <b class="cor-verde">SIMPLES</b> APENAS COPIANDO OS SINAIS.
                </div>
                <span class="partida-se" style="animation: positBrand 1.4s ease-in-out;">
                    MESMO SEM ENTENDER NADA DO MERCADO ESPORTIVO
                </span>
            </div>
            <div style="animation:positDas 1.8s ease-in-out;" class="copyTextVerb">
                <img alt="" border="0" src="https://1.bp.blogspot.com/-7NyCz78-UoA/YLjqwD51drI/AAAAAAAAHLo/QKrA7DGDLrAOPFHmbTcLVUGdLUkzwEDhgCLcBGAsYHQ/s0/logo%2Btitulo.png" />
            </div>
            <div class="sf-botao-comp" style="animation:positloader 1.8s ease-in-out;">
                <div class="centralizar-1400">
                    <span class="e1400-alunos">
                        Mais de <b>2000</b> alunos
                    </span>
                </div>
                <a href="https://go.hotmart.com/B52516840P?ap=05cb" target="_blank" class="botao-comp">
                    <div class="centralizar-box"><b class="texto-chamativo">
                            GARANTIR A MINHA VAGA
                        </b>
                        <span>Liberamos apenas 50 vagas!</span>
                    </div>
                </a>
                <div class="centralizar-box2 js-scroll slide-right"><i>Estamos com um número limitado de vagas.</i>
                    <div id="clockdiv">
                        <span class="days" style="display:none;"></span>
                        <div style="display:none;" class="smalltext">dias</div>
                        <span class="hours"></span>
                        <div class="smalltext">horas</div>
                        <span class="minutes"></span>
                        <div class="smalltext">minutos</div>
                        <span class="seconds"></span>
                        <div class="smalltext">segundos</div>
                    </div>

                </div>
            </div>
        </div>
        <div class="posit-leo leo-mobile js-scroll slide-right"></div>
    </div>
</div>
<div>
    <div id="beneficios" class="friends-section backg-rest">
        <div class="espacbackg-rest">
            <h3 class="margem-depo center-width js-scroll slide-left"><i style="margin-right: 6px;" class="fas fa-poll cor-amarelo"></i> Benefícios</h3>
            <ul class="sh-list sh-list-vc sh-list-style1" id="list-UnW7b1uJlj">
                <li class="sh-list-item js-scroll fade-in-bottom">
                    <span class="sh-list-icon">
                        <i class="fa fa-check"></i>
                    </span>
                    <span class="sh-list-content">
                        OPERE COM UM DOS MAIORES TIPSTERS DO BRASIL</span>

                </li>

                <li class="sh-list-item js-scroll fade-in-bottom">
                    <span class="sh-list-icon">
                        <i class="fa fa-check"></i>
                    </span>
                    <span class="sh-list-content">
                        ESPECIALISTA NO MERCADO DE ESCANTEIOS</span>

                </li>

                <li class="sh-list-item js-scroll fade-in-bottom">
                    <span class="sh-list-icon">
                        <i class="fa fa-check"></i>
                    </span>
                    <span class="sh-list-content">
                        MAIOR ODDS DO BRASIL</span>

                </li>

                <li class="sh-list-item js-scroll fade-in-bottom">
                    <span class="sh-list-icon">
                        <i class="fa fa-check"></i>
                    </span>
                    <span class="sh-list-content">
                        SUPORTE 24HRS</span>

                </li>

                <li class="sh-list-item js-scroll fade-in-bottom">
                    <span class="sh-list-icon">
                        <i class="fa fa-check"></i>
                    </span>
                    <span class="sh-list-content">
                        GARANTIA DE 7 DIAS </span>

                </li>

            </ul>
        </div>
        <video class="video-leo js-scroll slide-right video-posit" autoplay="" loop="" muted="" playsinline="" data-object-fit="cover">
            <source src="https://r1---sn-oxmcg-nn5l.googlevideo.com/videoplayback?expire=1623115363&ei=41W-YK_fI7vJzLUP9O6D4AQ&ip=45.161.147.161&id=784b31e5336caeb1&itag=22&source=blogger&mh=wl&mm=31&mn=sn-oxmcg-nn5l&ms=au&mv=m&mvi=1&pl=24&susc=bl&mime=video/mp4&vprv=1&dur=15.348&lmt=1623086556870681&mt=1623086225&txp=1311224&sparams=expire,ei,ip,id,itag,source,susc,mime,vprv,dur,lmt&sig=AOq0QJ8wRgIhAIu97YYqUz-g2XR4yhcmYsYtE7G77ttFBu5d3-pzequ0AiEApdwfehv9VwT3GpL4l8ndqwfHPCMI9dISxo6RIqhKW_M%3D&lsparams=mh,mm,mn,ms,mv,mvi,pl&lsig=AG3C_xAwRAIgeBGqeC3ckfDnRTEiCdEGVrEModEqsDX-cCQN-UD6TtkCIFzdA4bPELo6m56KHeszOx7wHMUnWDElhWnqAl5nJIJd&cpn=7aQjMoSZ9jBAucX-&c=WEB_EMBEDDED_PLAYER&cver=1.20210602.1.1" data-wf-ignore="true">
        </video>
    </div>
</div>

<div id="Servicos" class="section-steps">
    <div class="container-small-grid">
        <div class="js-scroll slide-right">
            <div class="step">
                <div class="steps-icon"><img src="https://1.bp.blogspot.com/-2f9wV65tCDw/YLlahgbOlgI/AAAAAAAAHMU/NNJxaLEucRw__-AbWPTDrVvQfPokdBqmACLcBGAsYHQ/s0/perfil-icon.png" height="70" alt=""></div>
                <div class="headline-7">Quem é Leonardo?</div>
                <p style="text-shadow: 1px 1px 3px #000;">Leonardo Bonavides, baiano de Salvador, é um jovem empreendedor que
                    encontrou nas apostas esportivas tino para um grande negócio.
                    Ao juntar a paixão pelo esporte e seus conhecimentos acerca do mercado de apostas,
                    Leonardo alinhou o útil ao agradável se tornando, reconhecidamente,
                    um dos mais bem sucedidos Trades esportivos de todo Brasil.
                    É o fundador da Cantos Race que vem operando no mercado esportivo desde 2014.</p>
            </div>
        </div>
        <div class="js-scroll slide-left">
            <div class="step">
                <div class="steps-icon"><img src="https://1.bp.blogspot.com/-YgFjvaS1JBI/YLlZzkylp1I/AAAAAAAAHL8/e7cQEGTZ26UwLrn0cG1xsijE4mujOfyygCLcBGAsYHQ/s0/beneficios.png" height="70" alt=""></div>
                <div class="headline-7">Benefícios do Grupo</div>
                <p style="text-shadow: 1px 1px 3px #000;">Cantos Race é uma séria e qualificada Consultora de Trade Esportivo.
                    A ideia de Leonardo Bonavides, seu fundador,
                    é fornecer um serviço de consultoria a baixo custo, tornando o investimento
                    acessível a todas e todos que tenham interesse em ganhar dinheiro com ODDS
                    esportivas. A Cantos Race garante um grande volume de entradas diárias,
                    com apostas todos os dias da semana. Com ODDS acima de 2.0, quem se filia ao grupo,
                    tem entradas em partidas de campeonatos de futebol em todo o mundo.
                    O histórico de apostas do grupo demonstra o sucesso e lucratividade da bancas associadas.</p>
            </div>
        </div>
        <div class="js-scroll slide-right">
            <div class="step">
                <div class="steps-icon"><img src="https://1.bp.blogspot.com/-tLU12RTgcdA/YLlZ0p2um5I/AAAAAAAAHMA/vzpnLr7Z8eoZhKDC3MXdgwnPAXG4acdPACLcBGAsYHQ/s0/idea.png" height="70" alt=""></div>
                <div class="headline-7">Diferencial</div>
                <p style="text-shadow: 1px 1px 3px #000;">Com o intuito de se destacar no mercado, a Cantos Race visa tornar-se a
                    Consultora de Trade Esportivo mais inclusiva do Brasil. Podendo beneficiar bancas
                    de diversos tamanhos – das mais humildes às mais recheadas.
                    A especialidade da casa são as entradas em escanteios,
                    o que permite apostas com ODDS altas e com retornos frequentemente positivos.</p>
            </div>
        </div>
    </div>
</div>
<div id="resultados" class="js-scroll slide-left">
    <div class="friends-section color-res">
        <div class="container-small">
            <h3 class="margem-depo center-width"><i style="margin-right: 6px;" class="fas fa-dollar-sign cor-amarelo"></i> Resultados</h3>

            <p>COM ANOS DE MERCADO, A CANTOS RACE INOVOU E CRIOU UMA ESTRATÉGIA ÚNICA,
                TORNANDO O LUCRO DE SEUS ALUNOS CADA VEZ MAIORES DENTRO DO TRADER ESPORTIVO.
                VEJA ALGUNS DOS NOSSOS RESULTADOS

                <!-- GALLERY  -->

            <div class="my-gallery" itemscope itemtype="http://schema.org/ImageGallery">

                <figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
                    <a href="https://1.bp.blogspot.com/-UMOM7aI-qcY/YJaobFSsp4I/AAAAAAAAHIg/m2VzfW3Z77EyK2q8JtAZNXlBP7GT22i9QCLcBGAsYHQ/s0/ods.png" itemprop="contentUrl" data-size="1080x1920">
                        <img src="https://1.bp.blogspot.com/-UMOM7aI-qcY/YJaobFSsp4I/AAAAAAAAHIg/m2VzfW3Z77EyK2q8JtAZNXlBP7GT22i9QCLcBGAsYHQ/s0/ods.png" itemprop="thumbnail" alt="Image description" />
                    </a>
                    <figcaption itemprop="caption description">Resultado de um dos nossos assinantes 1</figcaption>

                </figure>

                <figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
                    <a href="https://1.bp.blogspot.com/-nszmLS9TYWI/YJaov1NX0YI/AAAAAAAAHIo/7CTUvir1dpAONU2mMem_qZnQtRtrG4gEACLcBGAsYHQ/s0/ods1.png" itemprop="contentUrl" data-size="1080x1920">
                        <img src="https://1.bp.blogspot.com/-nszmLS9TYWI/YJaov1NX0YI/AAAAAAAAHIo/7CTUvir1dpAONU2mMem_qZnQtRtrG4gEACLcBGAsYHQ/s0/ods1.png" itemprop="thumbnail" alt="Image description" />
                    </a>
                    <figcaption itemprop="caption description">Resultado de um dos nossos assinantes 2</figcaption>
                </figure>

                <figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
                    <a href="https://1.bp.blogspot.com/-Jg4Ue4eX4SQ/YJao9k4QfTI/AAAAAAAAHIs/GTlLA-hyKM4SWX-AlRp_NyyAD495ZvRowCLcBGAsYHQ/s0/ods2.png" itemprop="contentUrl" data-size="1080x1920">
                        <img src="https://1.bp.blogspot.com/-Jg4Ue4eX4SQ/YJao9k4QfTI/AAAAAAAAHIs/GTlLA-hyKM4SWX-AlRp_NyyAD495ZvRowCLcBGAsYHQ/s0/ods2.png" itemprop="thumbnail" alt="Image description" />
                    </a>
                    <figcaption itemprop="caption description">Resultado de um dos nossos assinantes 3</figcaption>
                </figure>

            </div>

            <!--  -->

            </p>
            <div class="sf-botao-comp-footer">
                <a href="https://go.hotmart.com/B52516840P?ap=05cb" target="_blank" class="botao-comp-footer"> <b class="texto-chamativo-footer">GARANTIR A MINHA VAGA</b>
                </a>
                <span>Estamos com um número limitado de vagas. Liberamos apenas 50 vagas!</span>
                <div id="clockdiv2">
                    <span class="days" style="display:none;"></span>
                    <div style="display:none;" class="smalltext">dias</div>
                    <span class="hours"></span>
                    <div class="smalltext">horas</div>
                    <span class="minutes"></span>
                    <div class="smalltext">minutos</div>
                    <span class="seconds"></span>
                    <div class="smalltext">segundos</div>
                </div>

            </div>


        </div>
    </div>
</div>

<div id="depoimentos" class="js-scroll slide-left">
    <div class="friends-section color-benf">
        <div class="container-small">
            <h3 class="margem-depo center-width"><i style="margin-right: 6px;" class="fas fa-comments cor-amarelo"></i> Depoimentos</h3>
            <p>VEJA O QUE NOSSOS ALUNOS ESTÃO DIZENDO E LEMBRE-SE QUE ABRIMOS POUCAS VAGAS!</p>
            <!-- GALLERY  -->

            <div class="my-gallery" itemscope itemtype="http://schema.org/ImageGallery">

                <figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
                    <a href="https://1.bp.blogspot.com/-t3xaNNQ6rok/YJan3qg8QEI/AAAAAAAAHIU/dGzUtpN23rQEvoopCweMrBHQqc4qq1XVwCLcBGAsYHQ/s0/feed.png" itemprop="contentUrl" data-size="1080x1920">
                        <img src="https://1.bp.blogspot.com/-t3xaNNQ6rok/YJan3qg8QEI/AAAAAAAAHIU/dGzUtpN23rQEvoopCweMrBHQqc4qq1XVwCLcBGAsYHQ/s0/feed.png" itemprop="thumbnail" alt="Image description" />
                    </a>
                    <figcaption itemprop="caption description">Depoimento de um dos nossos assinantes 1</figcaption>

                </figure>

                <figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
                    <a href="https://1.bp.blogspot.com/--vyod9E8BlI/YJan3nADApI/AAAAAAAAHIQ/6vpr1h0a6ysg8hwT6yvwF_4WjrzaDeN_gCLcBGAsYHQ/s0/feed2.png" itemprop="contentUrl" data-size="1080x1920">
                        <img src="https://1.bp.blogspot.com/--vyod9E8BlI/YJan3nADApI/AAAAAAAAHIQ/6vpr1h0a6ysg8hwT6yvwF_4WjrzaDeN_gCLcBGAsYHQ/s0/feed2.png" itemprop="thumbnail" alt="Image description" />
                    </a>
                    <figcaption itemprop="caption description">Depoimento de um dos nossos assinantes 2</figcaption>
                </figure>

                <figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
                    <a href="https://1.bp.blogspot.com/-yRl0nGFzPOg/YJan3rDIfyI/AAAAAAAAHIM/IvXVfIfrYj4oIJCYWxM_4-26qHcZ0hoJgCLcBGAsYHQ/s0/feed1.png" itemprop="contentUrl" data-size="1080x1920">
                        <img src="https://1.bp.blogspot.com/-yRl0nGFzPOg/YJan3rDIfyI/AAAAAAAAHIM/IvXVfIfrYj4oIJCYWxM_4-26qHcZ0hoJgCLcBGAsYHQ/s0/feed1.png" itemprop="thumbnail" alt="Image description" />
                    </a>
                    <figcaption itemprop="caption description">Depoimento de um dos nossos assinantes 3</figcaption>
                </figure>

            </div>

            <!--  -->
            <div class="sf-botao-comp-footer">
                <a href="https://go.hotmart.com/B52516840P?ap=05cb" target="_blank" class="botao-comp-footer"> <b class="texto-chamativo-footer">GARANTIR A MINHA VAGA</b>
                </a>
                <span>Estamos com um número limitado de vagas. Liberamos apenas 50 vagas!</span>
                <div id="clockdiv3">
                    <span class="days" style="display:none;"></span>
                    <div style="display:none;" class="smalltext">dias</div>
                    <span class="hours"></span>
                    <div class="smalltext">horas</div>
                    <span class="minutes"></span>
                    <div class="smalltext">minutos</div>
                    <span class="seconds"></span>
                    <div class="smalltext">segundos</div>
                </div>

            </div>
        </div>
    </div>
</div>
</div>

<div id="garantia" style="border-top: 1px solid #fff;" class="js-scroll slide-left">
    <div class="friends-section color-benf">
        <div class="container-small">
            <div style="width: 100%;margin: 10vh auto 2vh auto;/* display: flex; */">
                <img src="https://1.bp.blogspot.com/-KGEJl71ivo8/YLk1ogQN-FI/AAAAAAAAHLw/CtjAHqDTTWAQbUgounKcPDCV1nPWgdq7gCLcBGAsYHQ/s0/7-dias-garantia.png">
                <p>Garantia 100% de satisfação, ou seja, você tem 7 dias para testar o nosso serviço,
                    e se ainda achar que não é para você, basta pedir reembolso e devolveremos o seu valor.
                    Sem perguntas e questionamentos. Neste caso nós asssumimos o risco.</p>
            </div>
            <div class="sf-botao-comp-footer">
                <a href="https://go.hotmart.com/B52516840P?ap=05cb" target="_blank" class="botao-comp-footer"> <b class="texto-chamativo-footer">GARANTIR A MINHA VAGA</b>
                </a>
                <span>Estamos com um número limitado de vagas. Liberamos apenas 50 vagas!</span>
            </div>
        </div>
    </div>
</div>
</div>