<?php

add_action('after_setup_theme', 'my_theme_setup');
function my_theme_setup()
{
    add_theme_support('post-thumbnails');

    add_theme_support('title-tag');

    register_nav_menus(
        array(
            'primary' => 'Primary'
        )
    );
}

add_action('wp_enqueue_scripts', 'cantos_race_scripts');

function cantos_race_scripts()
{
    // ESTILO CSS

    wp_enqueue_style('styleindex', get_template_directory_uri() .
        '/assets/CSS/styleindex.css');
    wp_enqueue_style('headcss', get_template_directory_uri() .
        '/assets/CSS/head.css');
    wp_enqueue_style('footer2', get_template_directory_uri() .
        '/assets/CSS/footer2.css');
    wp_enqueue_style('footer', get_template_directory_uri() .
        '/assets/CSS/footer.css');
    wp_enqueue_style('equipe', get_template_directory_uri() .
        '/assets/CSS/equipe.css');
    wp_enqueue_style('controlespaginas', get_template_directory_uri() .
        '/assets/CSS/controles-paginas.css');
    wp_enqueue_style('menu', get_template_directory_uri() .
        '/assets/CSS/Utilidades/menu.css');
    wp_enqueue_style('menumobile', get_template_directory_uri() .
        '/assets/CSS/Utilidades/menu.mobile.css');
    wp_enqueue_style('responsiveGallery', get_template_directory_uri() .
        '/assets/CSS/Utilidades/responsiveGallery.css');
    wp_enqueue_style('cores', get_template_directory_uri() .
        '/assets/CSS/Utilidades/cores.css');
    wp_enqueue_style('contact-form', get_template_directory_uri() .
        '/assets/CSS/Utilidades/contact-form.css');
    wp_enqueue_style('anims', get_template_directory_uri() .
        '/assets/CSS/Utilidades/anims.css');
    wp_enqueue_style('animateScroll', get_template_directory_uri() .
        '/assets/CSS/Utilidades/animate-scroll.css');
    // PHOTOSWIPE
    wp_enqueue_style('photoswipeCSS', get_template_directory_uri() .
        '/node_modules/photoswipe/dist/photoswipe.css');
    // 
    wp_enqueue_style('defaultskin', get_template_directory_uri() .
        '/node_modules/photoswipe/dist/default-skin/default-skin.css');
    // 
    wp_enqueue_style('misc', get_template_directory_uri() .
        '/assets/CSS/Utilidades/misc.css');

    // ESTILO JAVASCRIPT + JQUERY
    wp_enqueue_script('jquery', get_template_directory_uri() .
        'https://code.jquery.com/jquery-3.6.0.min.js', true);

    wp_enqueue_script('animacoes', get_template_directory_uri() .
        '/assets/JS/animacoes.js', array('jquery'), '1.1', true);
    wp_enqueue_script('animate-scroll', get_template_directory_uri() .
        '/assets/JS/animate-scroll.js', array('jquery'), '1.2', true);
    wp_enqueue_script('main', get_template_directory_uri() .
        '/assets/JS/main.js', array('jquery'), '1.3', true);
    // 
    wp_enqueue_script('menuaAnimjs', get_template_directory_uri() .
        '/assets/JS/menu.anim.js', array('jquery'), '1.4', true);
    // 
    wp_enqueue_script('responsive-nav', get_template_directory_uri() .
        '/assets/JS/responsive-nav.js', array('jquery'), '1.5', true);
    wp_enqueue_script('countdown', get_template_directory_uri() .
        '/assets/JS/countdown.min.js', array('jquery'), '1.6', true);
    // PHOTOSWIPE
    wp_enqueue_script('photoswipe', get_template_directory_uri() .
        '/assets/JS/photoswipe.js', array('jquery'), '1.7', true);
    // 
    wp_enqueue_script('photoswipeMin', get_template_directory_uri() .
        '/node_modules/photoswipe/dist/photoswipe.min.js', array('jquery'), '1.8', true);
    // 
    wp_enqueue_script('photoswipeUiDefault', get_template_directory_uri() .
        '/node_modules/photoswipe/dist/photoswipe-ui-default.min.js', array('jquery'), '1.9', true);
}
